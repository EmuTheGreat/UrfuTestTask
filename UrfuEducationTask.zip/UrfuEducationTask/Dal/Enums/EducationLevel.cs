﻿namespace Dal.Enums;

public enum EducationLevel
{
    Бакалавр,
    ПрикладнойБакалавриат,
    Специалист,
    Магистр,
    Аспирант

}