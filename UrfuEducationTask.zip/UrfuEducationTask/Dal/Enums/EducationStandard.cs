﻿namespace Dal.Enums;

public enum EducationStandard
{
    СУОС,
    ФГОС_ВО,
    СУТ,
    ФГОС_ВПО,
    ФГОС_3
}