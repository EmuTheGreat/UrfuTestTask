﻿namespace Dal.Enums;

public enum ModuleType
{
    STANDARD = 0
}