﻿namespace Dal.Repositories.Interfaces;

public interface IModuleRepository
{
    
}