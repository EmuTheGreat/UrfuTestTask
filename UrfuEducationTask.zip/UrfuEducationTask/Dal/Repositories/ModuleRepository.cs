﻿using Dal.Repositories.Interfaces;

namespace Dal.Repositories;

public class ModuleRepository : IModuleRepository
{
    
}