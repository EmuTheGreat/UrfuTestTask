﻿namespace Logic.Managers;

public class HeadService : IHeadService
{
    
}