﻿namespace Logic.Managers;

public interface IHeadService
{
    
}