﻿namespace Logic.Managers;

public interface IInstituteService
{
    
}