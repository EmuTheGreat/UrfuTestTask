﻿namespace Logic.Managers;

public class InstituteService : IInstituteService
{
    
}