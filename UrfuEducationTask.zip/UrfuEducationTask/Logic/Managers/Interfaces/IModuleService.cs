﻿namespace Logic.Managers.Interfaces;

public interface IModuleService
{
    
}