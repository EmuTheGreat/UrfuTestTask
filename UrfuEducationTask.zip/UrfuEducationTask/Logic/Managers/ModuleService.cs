﻿using Logic.Managers.Interfaces;

namespace Logic.Managers;

public class ModuleService : IModuleService
{
    
}