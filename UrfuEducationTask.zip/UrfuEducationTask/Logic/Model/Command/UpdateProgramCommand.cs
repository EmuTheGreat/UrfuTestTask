﻿using System.ComponentModel.DataAnnotations;
using Dal.Enums;

namespace Logic.Model.Command;

public class UpdateProgramCommand
{
    
}