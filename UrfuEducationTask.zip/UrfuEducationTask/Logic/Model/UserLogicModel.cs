﻿namespace Logic.Model;

public class UserLogicModel
{
    public string Phone { get; set; }
    public string Password { get; set; }
}